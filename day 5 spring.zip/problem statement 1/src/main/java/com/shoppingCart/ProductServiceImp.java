package com.shoppingCart;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class ProductServiceImp implements ProductService {

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void FindByProductId(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteByProductId(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateByProductId(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> allProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void FindByCategory(String name) {
		// TODO Auto-generated method stub
		
	}

}
